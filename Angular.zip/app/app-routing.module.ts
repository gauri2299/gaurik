import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomePageComponent } from './welcomePage/welcomePage.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
    { path: 'welcome_page', component: WelcomePageComponent },
    { path: 'login_page', component: LoginComponent }
  ];


@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
  