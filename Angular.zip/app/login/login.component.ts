import { Component, OnInit } from '@angular/core';
import { Credentials } from './credentials';
import { CustomerService } from 'src/app/customer.service';


@Component({

    selector: 'app-login',
    templateUrl : './login.component.html',
    styleUrls : ['./login.component.css']
               

})

export class LoginComponent implements OnInit{

    credentials: Credentials = new Credentials('ABC', 'abc@123');
    onSubmit(){
        this._custService.createCustomer(this.credentials)
      .subscribe(data => console.log(data));

    }

    constructor(private _custService: CustomerService) {

    }

    ngOnInit(){

    }
    
}
