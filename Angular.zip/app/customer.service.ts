import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class CustomerService {
    serviceUrl = "http://localhost:9090/PayWallet/api/check";

    constructor(private http: HttpClient) { }

    createCustomer(customerModel: Object): Observable<Object> {
        return this.http.post(`${this.serviceUrl}`, customerModel);
      }
    }