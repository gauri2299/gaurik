package com.example.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.app.Dao.UserDao;
import com.example.app.entity.User;

@Service
public class UserService {
	
	@Autowired
	UserDao userDao;

	public User checkLogin(User user) {
		return userDao.save(user);
	}

}
